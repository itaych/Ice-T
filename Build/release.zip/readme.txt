Welcome to Ice-T XE 2.8.1. Here are the files in this release:

readme.txt - you are here.
quickstart.txt - read this if you just want to get Ice-T running in an emulator without having to read a manual.
icet.txt - Ice-T user's guide.
icet.xex - The Ice-T executable.
icet_axlon.xex - Ice-T for Axlon Memory Board users.
icet_48k.xex - Ice-T version 1.1 for 48K computers.
icetdemo.vt - A demonstration animation, viewable with "VT-parse file".
vt102.txt - A technical reference of control codes accepted by the Ice-T terminal emulation.
icet_cfg.h - C language header documenting the ICET.DAT configuration file used for saving Ice-T's settings.
icet.atr - A bootable disk image containing executables, R: handlers, documentation, a text file viewer and the demo animation.
